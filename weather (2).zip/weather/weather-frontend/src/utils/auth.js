import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

export async function signup(name, email, password) {
  try {
    const response = await axios.post(`${API_URL}/auth/register`, {
      name,
      email,
      password,
    });
    
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Signup error:', error);
    return false;
  }
}

export async function login(username, password) {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, {
      username,
      password,
    });
    
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Login error:', error);
    return false;
  }
}

export async function logout() {
  localStorage.removeItem('token');
}

export async function checkAuthStatus() {
  const token = localStorage.getItem('token');
  
  if (!token) {
    return false;
  }
  
  try {
    const response = await axios.get(`${API_URL}/auth/me`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    
    return !!response.data.user;
  } catch (error) {
    localStorage.removeItem('token');
    return false;
  }
}

export function getAuthToken() {
  return localStorage.getItem('token');
}