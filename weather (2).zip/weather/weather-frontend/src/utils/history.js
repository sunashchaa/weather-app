import axios from 'axios';
import { getAuthToken } from './auth';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

export async function getSearchHistory() {
  try {
    const token = getAuthToken();
    
    if (!token) {
      throw new Error('Authentication required');
    }
    
    const response = await axios.get(`${API_URL}/history`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    
    return response.data;
  } catch (error) {
    console.error('History fetch error:', error);
    throw error;
  }
}

export async function deleteSearchHistory(id) {
  try {
    const token = getAuthToken();
    
    if (!token) {
      throw new Error('Authentication required');
    }
    
    await axios.delete(`${API_URL}/history/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    
    return true;
  } catch (error) {
    console.error('History delete error:', error);
    throw error;
  }
}