import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getSearchHistory, deleteSearchHistory } from '../utils/history';
import { getWeather } from '../utils/weather';

function History() {
  const [history, setHistory] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await getSearchHistory();
      setHistory(data);
    } catch (err) {
      setError('Failed to fetch search history. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteSearchHistory(id);
      setHistory(history.filter(item => item._id !== id));
    } catch (err) {
      setError('Failed to delete history item. Please try again.');
      console.error(err);
    }
  };

  const handleSearch = async (location) => {
    try {
      await getWeather(location);
      navigate('/');
    } catch (err) {
      setError('Failed to search for this location. Please try again.');
      console.error(err);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (history.length === 0 && !isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Search History</h1>
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Search History</h2>
            <p className="card-description">Your recent weather searches will appear here</p>
          </div>
          <div className="card-content text-center py-8">
            <p className="text-gray-500 dark:text-gray-400">No search history found</p>
            <button 
              className="btn btn-outline mt-4"
              onClick={() => navigate('/')}
            >
              Search Weather
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Search History</h1>
        <button 
          className="btn btn-outline"
          onClick={fetchHistory}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Refresh
        </button>
      </div>
      
      {error && (
        <div className="alert alert-error mb-6">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          {error}
        </div>
      )}
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {history.map((item) => (
          <div key={item._id} className="card">
            <div className="card-header pb-2">
              <h2 className="card-title text-lg">{item.location}</h2>
              <p className="card-description flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                {item.country || "Unknown"}
              </p>
            </div>
            <div className="card-content">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {new Date(item.createdAt).toLocaleDateString()}
                </div>
                <div className="text-lg font-semibold">
                  {item.temperature}°C
                </div>
              </div>
              <div className="flex items-center justify-between gap-2">
                <button 
                  className="btn btn-secondary flex-1"
                  onClick={() => handleSearch(item.location)}
                >
                  Search Again
                </button>
                <button 
                  className="btn btn-outline p-2"
                  onClick={() => handleDelete(item._id)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default History;