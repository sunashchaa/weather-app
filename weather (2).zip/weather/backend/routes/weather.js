const Router = require('@koa/router');
const weatherController = require('../controllers/weather');

const router = new Router();

router.get('/', async (ctx) => {
  const location = ctx.query.location;
  if (!location) {
    ctx.status = 400;
    ctx.body = { error: 'Location is required' };
    return;
  }

  try {
    const weatherData = await weatherController.getWeather(location, ctx.state.userId);
    ctx.body = weatherData;
  } catch (error) {
    ctx.status = 500;
    ctx.body = { error: error.message };
  }
});

module.exports = router;
