// history.js
const Router = require("@koa/router");
const { pool } = require("../config/db");

const router = new Router();

router.get("/", async (ctx) => {
  try {
    const userId = ctx.state.userId;

    // Use promise-based query
    const [rows] = await pool.query(
      "SELECT * FROM search_history WHERE user_id = ?",
      [userId]
    );

    if (rows && Array.isArray(rows)) {
      ctx.body = rows;
    } else {
      ctx.status = 404;
      ctx.body = { error: "No search history found for this user" };
    }
  } catch (error) {
    ctx.status = 500;
    ctx.body = { error: error.message };
  }
});

module.exports = router;
