// authRoutes.js
const Router = require('@koa/router');
const authController = require('../controllers/auth');

const router = new Router({ prefix: '/auth' });

router.post('/register', async (ctx) => {
  const { username, password } = ctx.request.body;
  await authController.register(username, password);
  ctx.status = 201;
  ctx.body = { message: 'User registered' };
});

router.post('/login', async (ctx) => {
  const { username, password } = ctx.request.body;
  const { token, expiresIn } = await authController.login(username, password);
  ctx.body = { token, expiresIn };
});

module.exports = router;