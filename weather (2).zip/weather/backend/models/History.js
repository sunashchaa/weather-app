const pool = require('../config/db');

module.exports = {
  /**
   * Log a search to history
   * @param {number} userId 
   * @param {string} location 
   * @returns {Promise<number>} Insert ID
   */
  async create(userId, location) {
    const [result] = await pool.execute(
      'INSERT INTO search_history (user_id, location) VALUES (?, ?)',
      [userId, location]
    );
    return result.insertId;
  },

  /**
   * Get user's search history
   * @param {number} userId 
   * @returns {Promise<array>} Array of history items
   */
  async findByUser(userId) {
    const [rows] = await pool.execute(
      'SELECT id, location, search_date FROM search_history WHERE user_id = ? ORDER BY search_date DESC',
      [userId]
    );
    return rows;
  },

  /**
   * Clear user's history
   * @param {number} userId 
   * @returns {Promise<void>}
   */
  async clearHistory(userId) {
    await pool.execute(
      'DELETE FROM search_history WHERE user_id = ?',
      [userId]
    );
  }
};