const Koa = require('koa');
const Router = require('@koa/router');
const bodyParser = require('koa-bodyparser');
require('dotenv').config();
const cors = require('cors');


const authRouter = require('./routes/auth');
const weatherRouter = require('./routes/weather');
const historyRouter = require('./routes/history');
const authMiddleware = require('./middleware/auth');

const app = new Koa();
app.use(cors());

const apiRouter = new Router({ prefix: '/v1' });

app.use(bodyParser());

apiRouter.use(authRouter.routes());
apiRouter.use('/weather', authMiddleware, weatherRouter.routes());
apiRouter.use('/history', authMiddleware, historyRouter.routes());

app.use(apiRouter.routes());
app.listen(process.env.PORT, () => console.log(`Server running on port ${process.env.PORT}`));