// history.js
const History = require('../models/History');

module.exports = {
  async getHistory(userId) {
    return await History.findByUser(userId);
  },

  async clearHistory(userId) {
    await History.clearHistory(userId);
    return { message: 'History cleared' };
  }
};