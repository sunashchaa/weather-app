// auth.js
const jwt = require('jsonwebtoken');
const User = require('../models/User');
require('dotenv').config(); // Load environment variables

module.exports = {
  async register(username, password) {
    return await User.create(username, password);
  },

  async login(username, password) {
    const user = await User.verifyCredentials(username, password);
    if (!user) throw new Error('Invalid credentials');

    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET, 
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    return { token, expiresIn: process.env.JWT_EXPIRES_IN };
  }
};
