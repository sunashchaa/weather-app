const axios = require('axios');
const { pool } = require('../config/db');
require('dotenv').config(); 

module.exports = {
  async getWeather(location, userId) {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${process.env.OPENWEATHER_API_KEY}&units=metric`
    );
    
    const weatherData = {
      location: response.data.name,
      temperature: response.data.main.temp,
      conditions: response.data.weather[0].description,
      humidity: response.data.main.humidity,
      windSpeed: response.data.wind.speed
    };

    await pool.execute(
      'INSERT INTO search_history (user_id, location) VALUES (?, ?)',
      [userId, location]
    );

    return weatherData;
  }
};